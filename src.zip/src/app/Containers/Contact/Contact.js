import React from "react";
import './Contact.css';

export class Contact extends React.Component{
    render() {

        return (
            <div className="home">
      
            <div className="home-left-banner">
            left banner</div>  
            <div className="home-right-banner">
            right banner</div>
        </div>
           
        );
    }
}

import React, { Component } from 'react';
import "./DetailDisasterSummary.css";

export class DetailDisasterSummary extends React.Component
{
        constructor(props) {
            super(props);

            this.goToSlide = this.goToSlide.bind(this);
            this.goToPrevSlide = this.goToPrevSlide.bind(this);
            this.goToNextSlide = this.goToNextSlide.bind(this);

            this.state = {
                activeIndex: 0
                //,sDetailDisasterReportData: []
            };
        }

        goToSlide(index) {
            this.setState({
            activeIndex: index
            });
        }

        goToPrevSlide(e) {
            e.preventDefault();

            let index = this.state.activeIndex;
            let { slides } = this.props;
            //let { slides } = this.state.sDetailDisasterReportData;
            let slidesLength = slides.length;

            if (index < 1) {
                index = slidesLength;
            }

            --index;

            this.setState({
                activeIndex: index
            });
        }

        goToNextSlide(e) {
            e.preventDefault();

            let index = this.state.activeIndex;
            let { slides } = this.props;
            //let { slides } = this.state.sDetailDisasterReportData;
            let slidesLength = slides.length - 1;

            if (index === slidesLength) {
                index = -1;
            }

            ++index;

            this.setState({
                activeIndex: index
            });
        }
       
        render() 
        {
            return (
                <div className="carousel">
                    <ul className="carousel__indicators">
                        {/* {this.state.sDetailDisasterReportData.map((slide, index) => */}
                        {this.props.slides.map((slide, index) =>
                            <li key={index}> 
                            <a  
                                className={
                                    index == this.state.activeIndex
                                        ? "carousel__indicator--active"
                                        : "carousel__indicator"
                                }
                                onClick={e => this.goToSlide(index)}
                            /> </li>
                         )}
                    </ul> 
                    <a href="#"  className="carousel__arrow-left"  onClick={e => this.goToPrevSlide(e)} />
                    <ul className="carousel__slides"  >
                        {/* { this.state.sDetailDisasterReportData.map((slide, index) => */}
                        { this.props.slides.map((slide, index) => 
                            <li  key={index}
                                className={
                                index == this.state.activeIndex
                                    ? "carousel__slide--active"
                                    : "carousel__slide"
                                }
                            >
                                <p className="carousel-slide-para">
                                    <strong className="carousel-slide__date">
                                        {slide.date}: 
                                    </strong>
                                    <strong className="carousel-slide__content">     
                                            {slide.content}  
                                    </strong>
                                </p>
                            </li>
                        )}

                    </ul>
                    <a href="#" className="carousel__arrow-right"  onClick={e => this.goToNextSlide(e)} />
                </div>
            );
        }
}
export default DetailDisasterSummary;


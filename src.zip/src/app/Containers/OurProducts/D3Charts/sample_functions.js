drawD3ChoroplethMap()
{
    
        // The svg
        var svg = d3.select("NewsMapDiv"),
        width = +svg.attr("width"),
        height = +svg.attr("height");

        // Map and projection
        var path = d3.geoPath();
        var projection = d3.geoMercator()
        .scale(70)
        .center([0,20])
        .translate([width / 2, height / 2]);

        // Data and color scale
        var data = d3.map();
        var colorScale = d3.scaleThreshold()
        .domain([100000, 1000000, 10000000, 30000000, 100000000, 500000000])
        .range(d3.schemeBlues[7]);

        // Load external data and boot
        d3.queue()
        .defer(d3.json, "https://raw.githubusercontent.com/holtzy/D3-graph-gallery/master/DATA/world.geojson")
        .defer(d3.csv, "https://raw.githubusercontent.com/holtzy/D3-graph-gallery/master/DATA/world_population.csv", function(d) { data.set(d.code, +d.pop); })
        .await(ready);

        function ready(error, topo) {

        // Draw the map
        svg.append("g")
        .selectAll("path")
        .data(topo.features)
        .enter()
        .append("path")
            // draw each country
            .attr("d", d3.geoPath()
            .projection(projection)
            )
            // set the color of each country
            .attr("fill", function (d) {
            d.total = data.get(d.id) || 0;
            return colorScale(d.total);
            });
        }
}
drawArcgisChoroplethMap()
{
    loadModules([   "esri/Map",
                      "esri/views/MapView",
                      "esri/layers/FeatureLayer",
                      "esri/layers/GeoJSONLayer",
                      "esri/widgets/Legend"], 
                                  options)
    .then(([Map, MapView, FeatureLayer, GeoJSONLayer, Legend]) => {

        const url ="http://localhost:8080/Images/all_month-1.geojson";
        const defaultSym = {
            type: "simple-fill", // autocasts as new SimpleFillSymbol()
            outline: {
              // autocasts as new SimpleLineSymbol()
            // color: [128, 128, 128, 0.2],
            color: "lightgray",
              width: "0.5px"
            }
        };

        const renderer = {
            type: "simple", // autocasts as new SimpleRenderer()
            symbol: defaultSym,
            label: "U.S. County",
            visualVariables: [
              {
                type: "color",
                field: "mag",
                normalizationField: "place",
                legendOptions: {
                  title: "% population in poverty by county"
                },
                stops: [
                  {
                    value: 0.1,
                    color: "#C1FFC1",
                    label: "<10%"
                  },
                  {
                    value: 0.3,
                    color: "#66FF66",
                    label: ">30%"
                  }
                ]
              }
            ]
        };
        const template ={
              title: "{place}",
              content: "{mag} of {place} people live below the poverty line.",
              fieldInfos: [
                {
                  fieldName: "mag",
                  format: {
                    digitSeparator: true,
                    places: 0
                  }
                },
                {
                  fieldName: "place",
                  format: {
                    digitSeparator: true,
                    places: 0
                  }
                }
              ]
        }

        const layer = new GeoJSONLayer({
            url: url,
            title: "Magnitude 2.5+ earthquakes from the last week",
            copyright: "USGS Earthquakes",
            popupTemplate: template,
            renderer: renderer
        });
        const map = new Map({
            basemap: "dark-gray-vector",
            layers: [layer]
        });

        const view = new MapView({
            container: 'NewsMapDiv',
            map: map,
            center: [-85.0502, 33.125524],
            zoom: 2
        });

    }).catch(function(error){
        console.log("ERROR: in drawArcgisChoroplethMap  ", error.details);
    });
}
drawArcgisBubbleMap()
{
  loadModules([       "esri/Map",
                        "esri/views/MapView",
                        "esri/layers/GeoJSONLayer",
                        "esri/widgets/Legend"], 
                    options)
    .then(([    Map, 
                MapView,
                GeoJSONLayer,
                Legend]) => 
    {
          
        const url ="http://localhost:8080/Images/all_month-1.geojson";
            //"https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_month.geojson";

        const template = {
            title: "Earthquake Info",
            content: "Magnitude {mag}  hit {place} "
        };

        const renderer = {
            type: "simple",
            field: "mag",
            symbol: {
            type: "simple-marker",
            color: "#66FF66",
            outline: {
                color: "white"
            }
            },
            visualVariables: [
            {
                type: "size",
                field: "mag",
                stops: [
                {
                    value: 2.5,
                    size: "14px"
                },
                {
                    value: 8,
                    size: "40px"
                }
                ]
            }
            ]
        };
        console.log("i am in arcgis bubble map before geojsonlayer");
        const geojsonLayer = new GeoJSONLayer({
            url: url,
            copyright: "USGS Earthquakes",
            popupTemplate: template,
            renderer: renderer //optional
        });

        const map = new Map({
            basemap: "dark-gray-vector",
            layers: [geojsonLayer]
        });

        const view = new MapView({
            container: 'NewsMapDiv',
            map: map,
            center: [-85.0502, 33.125524],
            zoom: 2
        });
    })
    .catch(function(error){
        console.log("ERROR: in drawArcgisBubbleMap  ", error.details);
    });
}
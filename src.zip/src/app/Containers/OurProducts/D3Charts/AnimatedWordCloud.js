import './Cloud';
  
export default function drawWordCloud(jsonData,selector, wordColor)
{
        var myWordCloud = wordCloud(selector);
        
        showNewWords(myWordCloud);

        function showNewWords(vis, i) {
                i = i || 0;
                vis.update(jsonData)
                setTimeout(function() { showNewWords(vis, i + 1)}, 2000)
        }

        function wordCloud(selector) 
        {
                var color = d3.scale.linear()
                        .range(wordColor)

                var fill = color;

                //Construct the word cloud's SVG element
                var svg = d3.select(selector).append("svg")
                // .attr("width", 500)
                // .attr("height", 600)
                .attr("width", 500)
                .attr("height", 300)
                .append("g")
                //.attr("transform", "translate(150,200)");
                .attr("transform", "translate(230,150)");

                //Draw the word cloud
                function draw(words) 
                {
                        var cloud = svg.selectAll("g text")
                                        .data(words, function(d) { return d.text; })

                        //Entering words
                        cloud.enter()
                                .append("text")
                                .style("font-family", "Impact")
                                .style("fill", function(d, i) { return fill(i); })
                                .attr("text-anchor", "middle")
                                .attr('font-size', 1)
                                .text(function(d) { return d.text; });

                        //Entering and existing words
                        cloud
                                .transition()
                                .duration(600)
                                .style("font-size", function(d) { return d.size + "px"; })
                                .attr("transform", function(d) {
                                        return "translate(" + [d.x, d.y] + ")rotate(" + d.rotate + ")";
                                })
                                .style("fill-opacity", 1);

                        //Exiting words
                        cloud.exit()
                                .transition()
                                .duration(200)
                                .style('fill-opacity', 1e-6)
                                .attr('font-size', 1)
                                .remove();
                }
                return {
                        update: function(words) {
                                d3.layout.cloud().size([500, 300])
                                .words(words)
                                .padding(5)
                                .rotate(function() { return ~~(Math.random() * 2) * 90; })
                                .font("Impact")
                                .fontSize(function(d) { return d.size; })
                                .on("end", draw)
                                .start();
                        }
                }
        }
}
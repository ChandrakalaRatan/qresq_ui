export default function drawLineGraph(data, barchartselector, barChartColor)
{ 

        var margin =  {top: 80, right: 10, bottom: 40, left: 60};
        var width = 580 - margin.left - margin.right;
        var height =320 - margin.top - margin.bottom;
        
        var maxTweets = Math.max.apply(Math, data.map(function(o) { return o.totalTweets; }));
        console.log("max tweet values",maxTweets)
        var yAxisDivider = 1;
        if (maxTweets > 4000) yAxisDivider = 1000;
        else if (maxTweets > 100 && maxTweets < 1000) yAxisDivider = 100;
        else if (maxTweets > 10 && maxTweets < 100) yAxisDivider = 1;

        var count=0;
        data.map(d=>{
           // d.rawDate = d.rawDate.substring(5, 10);
            d.totalTweets = Math.floor(d.totalTweets/yAxisDivider);
            count++;
           // console.log("value of array",d.rawDate,d.totalTweets);
        });
       // var n = count;
        

        // The number of datapoints
        console.log("number of data points",count)

    //    var xscale = d3.scale.ordinal()
    //         .domain(data.map(function(d) { return d.rawDate; }))
    //         .rangeRoundBands([0, width], .2);

    // create a dummy point
        if(count===1)
        {
            data.unshift({
                rawDate: "2000-00-01T00:00:00.000Z",
                totalTweets: 0
            })
            count++;
        }
        console.log("array content",data,count)
        var xscale = d3.scale.linear()
                .domain([0, count]) // input
                .range([0, width]);
    
     

        var yscale = d3.scale.linear()
            .domain([0, d3.max(data, function (d) { return d.totalTweets; }) ])
            .range([height, 0]);

        var xAxis  = d3.svg.axis().scale(xscale).orient("bottom");
        var yAxis  = d3.svg.axis().scale(yscale).orient("left");


        // append the svg object to the body of the page
        var svg = d3.select(barchartselector).append("svg")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
        .append("g")
            .attr("transform","translate(" + margin.left + "," + margin.top + ")");

        svg.append("g")
            .attr("class", "x axis")
            .attr("fill", "white")
            .attr("transform", "translate(0, " + height + ")")
            .call(xAxis);
       
        svg.append("g")
            .attr("class", "y axis")
            .attr("fill", "white")
            .call(yAxis);
        
        var path = svg.append("path")
            .datum(data)
            .attr("fill", "none")
            .attr("stroke", barChartColor[0])
            .attr("stroke-width", 1.5)
            .attr("d", d3.svg.line()
               // .x(function(d) { return xscale(d.date) })
                .x(function(d,i) { return xscale(i) })
                .y(function(d) { return yscale(d.totalTweets) })
                );
      
        // Add the area
        svg.append("path")
            .datum(data)
            .attr("fill", barChartColor[1])
            .attr("fill-opacity", .3)
            .attr("stroke", "none")
            .attr("d", d3.svg.area()
            .x(function(d,i) { return xscale(i)  })
            .y0( height )
            .y1(function(d) { return yscale(d.totalTweets) })
        );
        svg.selectAll(".dot")
            .data(data)
            .enter().append("circle") // Uses the enter().append() method
            .attr("class", "dot") // Assign a class for styling
            .attr("fill", barChartColor[2])
            .attr("cx", function(d,i) { return xscale(i) })
            .attr("cy", function(d) { return yscale(d.totalTweets) })
            .attr("r", 5)
}
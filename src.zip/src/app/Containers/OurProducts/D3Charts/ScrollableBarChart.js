
 export default function drawBarChart(data, barchartselector, barChartColor)
 {    
    var locYear='';                    
    var margin =  {top: 80, right: 10, bottom: 20, left: 40};
    var marginOverview = {top: 20, right: 30, bottom: 20, left: 10};
    var selectorHeight = 40;
    var width = 580 - margin.left - margin.right;
    var height =320 - margin.top - margin.bottom - selectorHeight;
    var heightOverview = 80 - marginOverview.top - marginOverview.bottom;
           
    var maxLength = d3.max(data.map(function(d){ return d.date.length}))
    var barWidth = maxLength * 3;
    var numBars = Math.round(width/barWidth);
    var isScrollDisplayed = barWidth * data.length > width;
           
    data.map(d=>{
        locYear = d.date.substring(0, 4);
        d.date = d.date.substring(5, 10);
    });

    var xscale = d3.scale.ordinal()
                        .domain(data.map(function(d) { return d.date; }))
                        .rangeRoundBands([0, width], .2);
    

    var yscale = d3.scale.linear()
                         .domain([0, d3.max(data, function (d) { return d.totalTweets; }) ])
                         .range([height, 0]);
   
    var xAxis  = d3.svg.axis().scale(xscale).orient("bottom");
    var yAxis  = d3.svg.axis().scale(yscale).orient("left");
      
    var svg = d3.select(barchartselector).append("svg")
                .attr("width", width + margin.left + margin.right + 10 )
                .attr("height", height + margin.top + margin.bottom + selectorHeight)
                .attr("fill", barChartColor[0]);
                
    var diagram = svg.append("g")
                     .attr("transform", "translate(" + (margin.left+20)+ "," + (margin.top-40) + ")");
      
    diagram.append("g")
           .attr("class", "x axis")
           .attr("fill", "white")
           .attr("transform", "translate(0, " + height + ")")
           .call(xAxis);
      
    diagram.append("g")
           .attr("class", "y axis")
           .attr("fill", "white")
           .call(yAxis);
      
    var bars = diagram.append("g");
      
    bars.selectAll("rect")
                .data(data, function (d) {return d.date; })
                .enter().append("rect")
                .attr("class", "bar")
                .attr("x", function (d) { return xscale(d.date); })
                .attr("y", function (d) { return yscale(d.totalTweets); })
                //.attr("width", xscale.rangeBand())
                .attr("width", data.length> 10 ? xscale.rangeBand(): 40)
                .attr("height", function (d) { return height - yscale(d.totalTweets); })
                .attr("fill", barChartColor[0]);
    
      
    if (isScrollDisplayed)
    {
        var xOverview = d3.scale.ordinal()
                        .domain(data.map(function (d) { return d.date; }))
                        .rangeBands([0, width], .2);

        var yOverview = d3.scale.linear().range([heightOverview, 0]);
                        yOverview.domain(yscale.domain());
        
        var subBars = diagram.selectAll('subBar')
                                .data(data)
        
        subBars.enter().append("rect")
            .classed('subBar', true)
            .attr({
                height: function(d) {
                    return heightOverview - yOverview(d.totalTweets);
                },
                width: function(d) {
                    return xOverview.rangeBand()
                },
                x: function(d) {
        
                    return xOverview(d.date);
                },
                y: function(d) {
                    return height + heightOverview + yOverview(d.totalTweets)
                }
            })
            .attr("fill", barChartColor[1]);
        
        var displayed = d3.scale.quantize()
                    .domain([0, width])
                    .range(d3.range(data.length));
        
        diagram.append("rect")
                    .attr("transform", "translate(0, " + (height + margin.bottom) + ")")
                    .attr("class", "mover")
                    .attr("x", 10)
                    .attr("y", 10)
                    .attr("height", selectorHeight)
                    .attr("width", Math.round(parseFloat(numBars * width)/data.length))
                    .attr("pointer-events", "all")
                    .attr("cursor", "ew-resize")
                    .call(d3.behavior.drag().on("drag", display))
                    .attr("fill", barChartColor[2]);
    }
    function display () 
    {
        var x = parseInt(d3.select(this).attr("x")),
            nx = x + d3.event.dx,
            w = parseInt(d3.select(this).attr("width")),
            f, nf, new_data, rects;
    
        if ( nx < 0 || nx + w > width ) return;
    
        d3.select(this).attr("x", nx);
    
        f = displayed(x);
        nf = displayed(nx);
    
        if ( f === nf ) return;
    
        new_data = data.slice(nf, nf + numBars);
    
        xscale.domain(new_data.map(function (d) { return d.date; }));
        diagram.select(".x.axis").call(xAxis);
    
        rects = bars.selectAll("rect")
          .data(new_data, function (d) {return d.date; });
    
        rects.attr("x", function (d) { return xscale(d.date); });
    
        rects.enter().append("rect")
          .attr("class", "bar")
          .attr("x", function (d) { return xscale(d.date); })
          .attr("y", function (d) { return yscale(d.totalTweets); })
          .attr("width", xscale.rangeBand())
          .attr("height", function (d) { return height - yscale(d.totalTweets); });
    
        rects.exit().remove();
    };
}

export default function drawAnimatedLineGraph(data, sliderSelector, barChartSelector, barChartColor)
{

        var maxTweets = Math.max.apply(Math, data.map(function(o) { return o.totalTweets; }));
        console.log("max tweet values",maxTweets)
        var yAxisDivider = 1;
        if (maxTweets > 4000) yAxisDivider = 1000;
        else if (maxTweets > 100 && maxTweets < 1000) yAxisDivider = 100;
        else if (maxTweets > 10 && maxTweets < 100) yAxisDivider = 1;
       const monthNames = {'01':'Jan', '02':'Feb', '03':'Mar', 
                            '04':'Apr', '05':'May', '06':'Jun',
                           '07':'Jul', '08':'Aug', '09':'Sep', 
                           '10':'Oct', '11':'Nov', '12':'Dec'};
        var count=0;
        var mon,dt;
        data.map(d=>{
            mon = d.rawDate.substring(5, 7);
            dt =  d.rawDate.substring(8, 10);
            d.newDate = dt+ monthNames[mon];
            d.newtotalTweets = d.totalTweets;
            d.totalTweets = Math.floor(d.totalTweets/yAxisDivider);
            count++;
        });
        // create a dummy point
        if(count===1)
        {
            data.unshift({
                rawDate: "2000-00-01T00:00:00.000Z",
                newDate: Number(dt-1) + monthNames[mon],
                totalTweets: 0,
                newtotalTweets: 0
            })
            count++;
        }
        var margin =  {top: 40, right: 10, bottom: 80, left: 60},
            width = 580 - margin.left - margin.right,
            height =330 - margin.top - margin.bottom;
        
        var xscale = d3.scale.linear()
            .domain([0, count]) 
            .range([0, width]);

        var yscale = d3.scale.linear()
            .domain([-1, d3.max(data, function (d) { return d.totalTweets; }) ])
            .range([height, 0]);

        var xAxis  = d3.svg.axis().scale(xscale).orient("bottom");
        var yAxis  = d3.svg.axis().scale(yscale).orient("left");

        var svg = d3.select(barChartSelector).append("svg")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
        .append("g")
                .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
        
        svg.append("g")
            .attr("class", "x axis")
            .attr("fill", "white")
            .attr("transform", "translate(0, " + height + ")")
            .call(xAxis);
            
        svg.append("g")
            .attr("class", "y axis")
            .attr("fill", "white")
            .call(yAxis);

        // create a tooltip
        var Tooltip = d3.select(barChartSelector)
            .append("div")
            .style("opacity", 0)
            .attr("class", "tooltip")
            .style("background-color", "white")
            .style("border", "solid")
            .style("border-width", "2px")
            .style("border-radius", "5px")
            .style("padding", "5px")

        // Three function that change the tooltip when user hover / move / leave a cell
        var mouseover = function(d) {
            Tooltip
            .style("opacity", 1)
        }
        var mousemove = function(d) {
            Tooltip
            .html(d.newtotalTweets+ " tweets on "+d.newDate) //+" on "+d.rawDate
            .style("left", (d3.mouse(this)[0]+70) + "px")
            .style("top", (d3.mouse(this)[1]) + "px")
        }
        var mouseleave = function(d) {
            Tooltip
            .style("opacity", 0)
        }
        // draw line
        var path = svg.append("path")
        .datum(data)
        .attr("fill", "none")
        .attr("stroke", barChartColor[1])
        .attr("stroke-width", 4)
        .attr("d", d3.svg.line()
            .x(function(d,i) { return xscale(i) })
            .y(function(d) { return yscale(d.totalTweets) }));

        // Add the points
        svg.selectAll(".dot")
            .data(data)
            .enter()
            .append("circle") 
                .attr("class", "dot") 
                .attr("fill", barChartColor[2])
                .attr("cx", function(d,i) { return xscale(i) })
                .attr("cy", function(d) { return yscale(d.totalTweets) })
                .attr("r", 5)
                .attr("stroke", "#69b3a2")
                .attr("stroke-width", 3)
                .attr("fill", "white")
                .on("mouseover", mouseover)
                .on("mousemove", mousemove)
                .on("mouseleave", mouseleave)

        var area = d3.svg.area()
                .x(function(d,i) { return xscale(i)  })
                .y0(height)
                .y1(function(d) { return yscale(d.totalTweets) });

        // Add the area
        svg.append("path")
            .attr("class", "area")
            .attr("d",area(data))
            .attr("fill", barChartColor[0])
            .attr("fill-opacity", .6)
            .attr("stroke", "none")
            

        var totalLength = path.node().getTotalLength();
        console.log(totalLength);
                path
                    .attr("stroke-dasharray", totalLength + " " + totalLength)
                    .attr("stroke-dashoffset", totalLength)
                    .transition()
                        .duration(5000)
                        .ease("linear")
                        .attr("stroke-dashoffset", 0);

        // var area = svg.select(".area")
        //         area
        //             .attr("transform", "translate(0, " + width + ")")
        //             .transition()
        //                 .duration(5000)
        //             .attr("transform", "translate(0,0)");

}
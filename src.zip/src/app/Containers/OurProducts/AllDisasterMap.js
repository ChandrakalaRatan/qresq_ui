import React from "react";
import ReactDOM from "react-dom";
import { loadModules } from 'esri-loader';

import { SpecificDisasterDetailMap } from './SpecificDisasterDetailMap';

const options = {
    url: 'https://js.arcgis.com/4.12/'
};

var gDisasterDataArray =[];
var gLatitude = 0;
var gLongitude = 0;  
var self;

const styles =  {
    AllDisasterMapDiv: {
        padding: 0,
        margin: 0,
        height: '100%',
        width: '120%'
    },
}

export class AllDisasterMap extends React.Component{
    constructor(props) {
        super(props);
        self=this;
        this.state = props;
        this.state = {
            sLongitude: 0,
            sLatitude: 0,
            requirementKey: Math.random(),
            sAllDisasterTypeData: [],
            sSingleDisasterTypeDataRecord: {}  
          };
          
    }  
  
    componentDidMount() {
        this.fetchAllDisasterTypeData();
    } 
    
    fetchAllDisasterTypeData() { 
        console.log("@@@@@@@@@@ this.props.sDateAndDisasterFilter",this.props.sDateAndDisasterFilter); 
        const lEndPoint = "http://167.86.104.221:8050/api/qresq/search";
            try 
            {
                fetch(lEndPoint,{
                    headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json'
                            },
                            method: "POST",
                            body: JSON.stringify({size: 2000, indexName: 'test_alert'
                            ,exactMatch : true
                            ,filters: this.props.sDateAndDisasterFilter  
                        })   
                })
                .then(response => response.json()) 
                .then(json => {
                    this.setState({
                        sAllDisasterTypeData: json.results,
                        requirementKey: Math.random() 
                    })  
                    console.log("@@@@@@@@@@ I am in fetchAllDisasterTypeData in DISASTERTYPE", JSON.stringify(json));
                })
                .catch(error =>{
                  console.log("ERROR" + error);     
                })
            } 
            catch (error) {
                console.log(error);
            }         
    }

    componentDidUpdate(){
        loadModules([
                        'esri/Map', 
                        'esri/views/MapView',
                        "esri/layers/FeatureLayer",
                        "esri/Graphic",
                        "esri/geometry"
                    ],options
                    )
        .then(([
                Map, 
                MapView,
                FeatureLayer,
                Graphic
             ]) => {
            var lURL = "https://www.arcgis.com/apps/Embed/index.html?webmap=de6c0622b7944b48a3a80c997d6835f2";
            
            var featureLayer = new FeatureLayer({ url: lURL });
            var popUpTemplate = {};
            var TemplateContent = {};

            const map = new Map({ 
                basemap: "dark-gray-vector"
                ,layer: featureLayer
               // ,spacialReference: featureLayer.spacialReference
            });
        
            // Create the MapView
            const view = new MapView({
                container: "AllDisasterMapDiv",
                map: map,
                zoom: 2,
                center: {
                    x: 38.9637,
                    y: 35.2433
                }
            });
    

            //Plot the markers on the map
            this.state.sAllDisasterTypeData.map(itemDisaster => 
            {
                var locURL='http://localhost:8080/Images/';   
             
                    if(itemDisaster.disasterType.trim() === 'EQ'){

                        itemDisaster.DiasterName = "Earth Quake";
                        gDisasterDataArray.push(itemDisaster);

                        if(itemDisaster.intensity.trim() === 'Green'){
                            locURL= locURL + "green-earthquake.png";  
                        }
                        if(itemDisaster.intensity.trim() === 'Red'){
                            locURL= locURL + "red-earthquake.png"; 
                        }
                        if( itemDisaster.intensity.trim() === 'Orange'){
                            locURL= locURL + "orange-earthquake.png"; 
                        }
                    }
                    if(itemDisaster.disasterType.trim() === 'FL'){

                        itemDisaster.DiasterName = "Flood";
                        gDisasterDataArray.push(itemDisaster);

                        if(itemDisaster.intensity.trim() === 'Green'){
                            locURL= locURL + "green-flood.png";
                        }
                        if(itemDisaster.intensity.trim() === 'Red'){
                            locURL= locURL + "red-flood.png";
                        }
                        if( itemDisaster.intensity.trim() === 'Orange'){
                            locURL= locURL + "orange-flood.png"; 
                        }
                            
                    }
                    if(itemDisaster.disasterType.trim() === 'TC'){

                        itemDisaster.DiasterName = "Cyclone and Storm";
                        gDisasterDataArray.push(itemDisaster);

                        if(itemDisaster.intensity.trim() === 'Green'){
                            locURL= locURL + "green-storm.png";
                        }
                        if(itemDisaster.intensity.trim() === 'Red'){
                            locURL= locURL + "red-storm.png";
                        }
                        if( itemDisaster.intensity.trim() === 'Orange'){
                            locURL= locURL + "orange-storm.png"; 
                        }   
                    }
                    if(itemDisaster.disasterType.trim() === 'HU'){

                        itemDisaster.DiasterName = "Humanitarian";
                        gDisasterDataArray.push(itemDisaster);

                        if(itemDisaster.intensity.trim() === 'Green'){
                            locURL= locURL + "green-humanitarian.png";
                        }
                        if(itemDisaster.intensity.trim() === 'Red'){
                            locURL= locURL + "red-humanitarian.png"; 
                        }
                        if( itemDisaster.intensity.trim() === 'Orange'){
                            locURL= locURL + "orange-humanitarian.png";    
                        }
                    }   
                    if( itemDisaster.disasterType.trim() === 'EQ' || itemDisaster.disasterType.trim() === 'TC' ||
                        itemDisaster.disasterType.trim() === 'FL' || itemDisaster.disasterType.trim() === 'HU')
                    { 
                        var pictureGraphic = new Graphic({
                            geometry: {
                                type: "point",
                                longitude: Number(itemDisaster.geolocation.lon),
                                latitude: Number(itemDisaster.geolocation.lat)
                            },
                            symbol: {
                                type: "picture-marker",  
                                url: locURL,
                                width: "24px",
                                height: "24px"
                            }
                        });
                    }
                      view.graphics.add(pictureGraphic); 
            }); // gDisasterDataArray.map 
        
           

            view.on("double-click", function (event) 
            {
                var opts = {
                    duration: 2000, 
                    easing: "linear "  
                };
                view.goTo({
                    zoom: view.zoom + 3,
                    center:  view.toMap({ x: event.x, y: event.y })
                },opts);
                event.stopPropagation();
            });
        //view.hitTest(event).
            view.on("click", function (event) 
            { 
                //event.stopPropagation();
                console.log("double click",event);
                //event.stopPropagation();
                view.hitTest(event).then( function(response) 
                {    
                    var plat = Math.round(event.mapPoint.latitude * 100) / 100;
                    var plon = Math.round(event.mapPoint.longitude * 100) / 100;
                    
                    console.log("in hittest",response);
                    // console.log(gDisasterDataArray);
                    // gLongitude = Number(response.screenPoint.mapPoint.longitude);
                    // gLatitude = Number(response.screenPoint.mapPoint.latitude);
                
                    // var plon = Number(gLongitude);
                    // var plat = Number(gLatitude);
                    // plon = Math.round(plon * 100) / 100
                    // plat = Math.round(plat * 100) / 100
                    var pr = 1;
                    var llat,llon;
                    console.log("plat, plon",plat, plon);
                    //find the closest latitude and longitude check to find which marker is clicked
                    gDisasterDataArray.map(itemDisaster => 
                    {
                        llat = Number(itemDisaster.geolocation.lat);
                        llon = Number(itemDisaster.geolocation.lon)
                        var xlon = plon - llon;
                        var xlat = plat - llat;
                        //console.log("in gDisasterDataArray array",itemDisaster);
                        if (((xlon*xlon) + (xlat*xlat))<(pr*pr)) 
                        {     
                            self.state.sSingleDisasterTypeDataRecord = itemDisaster;
                            console.log("single record",self.state.sSingleDisasterTypeDataRecord);  
                            self.state.sLongitude = Number(itemDisaster.geolocation.lon);
                            self.state.sLatitude = Number(itemDisaster.geolocation.lat); 

                            var centerPoint = view.center.clone();
                            TemplateContent=    "<b>Magnitude:      </b> "+ itemDisaster.magnitude +"    "+ itemDisaster.unit+"<br>"+
                                                "<b>Date Occured:       </b>"+ itemDisaster.dateOccur+"<br>"+
                                                "<b>Diaster Name:       </b>"+ itemDisaster.DiasterName+"<br>"+
                                                "<b>Event Id:       </b>"+ itemDisaster.eventId+"<br>"+
                                                "<b>Geolocation:     </b>"+itemDisaster.geolocation.lat + "     " + itemDisaster.geolocation.lon+"</br></br></br>";

                            
                            // if( itemDisaster.intensity === 'Red' || itemDisaster.intensity === 'Orange' )
                            // {
                            //     TemplateContent =   TemplateContent  +
                            //                         "<a href= 'http://localhost:8080/resqhome'"+
                            //                         "target='{ReactDOM.render( <AffectedAreaMap   latitude={self.state.sLatitude} longitude={self.state.sLongitude} DisasterDataArray = {gDisasterDataArray} SingleDisasterDataRecord={self.state.sSingleDisasterTypeDataRecord} />,document.getElementById('DisasterTypeView')); } '>"+
                            //                         "Detail Disaster Report</a>"
                            // }
                            popUpTemplate = {
                                title: itemDisaster.DiasterName +" in " + itemDisaster.country,
                                location: centerPoint,
                                //fetchFeatures: true,
                                content: TemplateContent
                            };
                            if( itemDisaster.intensity.trim() === 'Green' ){
                                view.popup.autoOpenEnabled = false;
                                view.popup.open(popUpTemplate); 
                                console.log("popUpTemplate",popUpTemplate); }

                            if( itemDisaster.intensity.trim() === 'Red' || 
                                itemDisaster.intensity.trim() === 'Orange' ){
                                // view.popup.on("trigger-action", function(event){
                                    ReactDOM.render(
                                        <SpecificDisasterDetailMap  
                                            latitude={self.state.sLatitude} 
                                            longitude={self.state.sLongitude} 
                                            DisasterDataArray = {gDisasterDataArray}
                                            SingleDisasterDataRecord={self.state.sSingleDisasterTypeDataRecord}
                                        />,document.getElementById('AllDisasterMapDiv'));
                                 
                                //});
                            }//if( itemDisaster.intensity

                        }//if (((xlon*xlon) + (xlat*xlat))<(pr*pr)) 
                    });  //gDisasterDataArray.map
                });//hitTest      
            }); //view.on
          
        }).catch(function(error){
            console.log("disaster type map then Error details: ", error);
        }); //then
    }    
    renderMap() 
    {   
        if(this.state.status === 'loading') {
            return <div>loading</div>;
        }
    }//renderMap
    render() 
    {
        return(
            <div id='AllDisasterMapDiv' style={ styles.AllDisasterMapDiv }>
                {this.renderMap()}
            </div>    
        );  
    }//render 
}//class
    
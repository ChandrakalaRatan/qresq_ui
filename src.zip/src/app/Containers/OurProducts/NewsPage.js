import React, { Component } from 'react';
import { loadModules } from 'esri-loader';
import drawBarChart from "./D3Charts/ScrollableBarChart";
import drawWordCloud from "./D3Charts/AnimatedWordCloud";
import drawLineGraph from "./D3Charts/LineGraph";
import drawAnimatedLineGraph from "./D3Charts/AnimatedLineGraph";

import {barChartData} from "./D3Charts/BarChartData";

import "./NewsPage.css";
import './D3Charts/Cloud';

const options = {
    url: 'https://js.arcgis.com/4.12/'
    
};
//LIGHT GREEN
const wordCloudColor =   [   '#CCFFCC','#C1FFC1','#9AFF9A','#66FF66','#33FF33',
                            '#00FF00','#00EE00','#4BB74C','#00CD00','#009900',
                            '#008B00','#008000','#006400','#004F00','#003300'
                        ];
const barChartColor =   [   
                            "#66FF66","#C1FFC1","#008000"
                        ];

const heatMapColor = [
                            { color: "rgba(0,128,0, 0)", ratio: 0 },
                            { color: "#004F00", ratio: 0.08 },
                            { color: "#006400", ratio: 0.12 },
                            { color: "#008000", ratio: 0.1 },
                            { color: "#008B00", ratio: 0.2 },

                            { color: "#00CD00", ratio: 0.3 },
                            { color: "#00EE00", ratio: 0.4 },
                            { color: "#00FF00", ratio: 0.5 },
                            { color: "#33FF33", ratio: 0.6 },

                            { color: "#9AFF9A", ratio: 0.7 },
                            { color: "#C1FFC1", ratio: 0.8 },
                            { color: "#CCFFCC", ratio: 0.9 },
                            { color: "#F0FFF0", ratio: 1 }
                        ];


const styles =  {
    NewsPageDiv: {
        marginLeft: 0, 
        marginTop: 0, 
        width: '100%',
        height: '100%',
        position: 'absolute',
        backgroundColor: 'transparent'
    },
    NewsMapDiv: {
        marginLeft: 0, 
        marginTop: 0, 
        width: '45%',
        height: '100%',
        position: 'absolute',
        backgroundColor: 'transparent'
    }, 
    NewsChartDiv: {
        marginLeft: '45%',
        marginTop: 0, 
        width: '55%',
        height: '100%', 
        position: 'absolute',
        border: '1px solid black',
        outlineStyle: 'solid',
        outlineColor: 'invert',
        backgroundColor: 'transparent'
    },
    basemapGalleryDiv:{
        width: '5%',
        height: '10%',
        position: 'absolute',
        marginTop: 0, 
        marginLeft: '0'
    } 
}
  
export class NewsPage extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            locNewsBarChartData: [],
            locNewsBarChartFlag: false,
            locNewsWorldCloudData: [],
            locNewsWorldCloudFlag: false,
            locNewsMapData: [],
            locNewsMapDataFlag: false,
            locTotalNewsCount: 0
        }
    }
    componentDidMount() 
    {  
        console.log("event id",this.props.SingleDisasterDataRecord.qresqid);
        this.newsWordCloudFetch();
        this.newsBarChartFetch();
        this.newsMapFetch();
    }
    newsMapFetch() 
    {  
        const endPoint = "http://167.86.104.221:8050/api/news/groupByLocation?index=dhnews&eventId="
                         +this.props.SingleDisasterDataRecord.qresqid;
                                  //+"1111";
        fetch(endPoint,{
                      headers: {
                                  'Accept': 'application/json',
                                  'Content-Type': 'application/json'
                              },
                              method: "GET"
        })
        .then(response => response.json()) 
        .then(json => {
            console.log("new map fetch",json); 
            var count=0;
            json.results.map(newdata =>{
                this.state.locNewsMapData.push({
                    "id" : count++,
                    "city": newdata.city,
                    "totalTweets": newdata.totalTweets,
                    "longitude": newdata.geoLocation.lon,
                    "latitude": newdata.geoLocation.lat
                })  
            });
              this.setState({
                locNewsMapDataFlag: true
              }) 
        })
        .catch(error =>{
            console.log("ERROR in newsMapFetch   " + error);     
        })                       
    }
    newsBarChartFetch() 
    {  
        const endPoint =   "http://167.86.104.221:8050/api/news/trendingByDate?index=dhnews&eventId="
                           +this.props.SingleDisasterDataRecord.qresqid+"&groupBy=DAY";
                            //+"1111&groupBy=DAY";
        fetch(endPoint,{
                headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json'
                        },
                        method: "GET"
        })
        .then(response => { 
           // console.log("response", response);
            var contentType = response.headers.get('content-type');
            if(contentType && contentType.includes('application/json')) {
               // console.log(response.json())
                return response.json();
            }
            throw new TypeError("Oops, we haven't got JSON!");
        }) 
        .then(json => {
            this.setState({
                locNewsBarChartData: json.results,
                locNewsBarChartFlag: true
            }) 
           // console.log("result",JSON.stringify(json));             
        })
        .catch(error =>{
            console.log("ERROR  in newsBarChartFetch " + error);     
        })           
    }

    newsWordCloudFetch() 
    {  
        console.log("newsWordCloudFetch  " + this.props.SingleDisasterDataRecord.qresqid);  
        const endPoint =    "http://167.86.104.221:8050/api/dasboard/wordCloud?index=news_wordcloud&eventId="
                            +this.props.SingleDisasterDataRecord.qresqid;
        fetch(endPoint,{
            headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json'
                    },
                    method: "GET"
        })
        .then(response => response.json()) 
        .then(json => {
           
            this.setState({
                locNewsWorldCloudData: json.results,
                locNewsWorldCloudFlag: true
            })  
            //console.log(response);  
            //console.log("newsWordCloudFetch  " + JSON.stringify(json.results));           
        })
        .catch(error =>{
            console.log("ERROR in newsWordCloudFetch  " + error);     
        })  
    }

    componentDidUpdate()
    {
        
        const wordCloudSelector = document.getElementById('wordcloud'); 
        const barChartSelector = document.getElementById('barchart'); 
        const sliderSelector = document.getElementById('simpleslider');
        //console.log("wordCloudSelector" + wordCloudSelector);    
        var wordCloudJsonData =[];
    
        var maxTweets = Math.max.apply(Math, this.state.locNewsWorldCloudData.map(o=> { return o.totalTweets; }));
        //console.log(" maxTweets  " + maxTweets);   
        var tweetCount= maxTweets > 1000 ? Math.floor(maxTweets/5): maxTweets;
        
        //console.log(" tweetCount  " + tweetCount);  
        this.state.locNewsWorldCloudData.map(jsondata =>{
            if(jsondata.totalTweets > 0 && jsondata.totalTweets <= tweetCount)
            {
                wordCloudJsonData.push({
                    text: jsondata.word,
                    totalTweets: jsondata.totalTweets,
                    size: 14
                }) 
            }
            if(jsondata.totalTweets > tweetCount && jsondata.totalTweets <= tweetCount*2)
            {
                wordCloudJsonData.push({
                    text: jsondata.word,
                    totalTweets: jsondata.totalTweets,
                    size: 18
                }) 
            }
            else if(jsondata.totalTweets > tweetCount*2 && jsondata.totalTweets <= tweetCount*3){
                wordCloudJsonData.push({
                    text: jsondata.word,
                    totalTweets: jsondata.totalTweets,
                    size: 22
                })  
            }
            else if(jsondata.totalTweets > tweetCount*3 && jsondata.totalTweets <= tweetCount*4){
                wordCloudJsonData.push({
                    text: jsondata.word,
                    totalTweets: jsondata.totalTweets,
                    size: 26
                })  
            }
            else if(jsondata.totalTweets > tweetCount*4 && jsondata.totalTweets <= tweetCount*5){
                wordCloudJsonData.push({
                    text: jsondata.word,
                    totalTweets: jsondata.totalTweets,
                    size: 30
                }) 
            }
        });
 
        if(this.state.locNewsWorldCloudFlag === true){ 
            // console.log(" wordCloudJsonData  " + wordCloudJsonData); 
            drawWordCloud(wordCloudJsonData, wordCloudSelector,wordCloudColor);
            this.setState({
                locNewsWorldCloudFlag: false
            });
        }
        
        if(this.state.locNewsBarChartFlag === true){
            this.state.locNewsBarChartData.map(d=>{ 
                this.state.locTotalNewsCount = this.state.locTotalNewsCount + d.totalTweets
            })
            //drawBarChart(this.state.locNewsBarChartData, barChartSelector,barChartColor);
            //drawLineGraph(this.state.locNewsBarChartData, barChartSelector,barChartColor);
            drawAnimatedLineGraph(this.state.locNewsBarChartData, sliderSelector,barChartSelector,barChartColor);
            //barChartData
            this.setState({
                locNewsBarChartFlag: false
            });
        }
        if(this.state.locNewsMapDataFlag === true){
            this.drawArcgisHeatMap();
            this.setState({
                locNewsMapDataFlag: false
            });
        }
    }


    drawArcgisHeatMap()
    {
      loadModules([       "esri/Map",
                            "esri/views/MapView",
                            "esri/layers/FeatureLayer",
                            "esri/Graphic",
                            "esri/widgets/Legend"], 
                                      options)
        .then(([    Map, 
                    MapView,
                    FeatureLayer,
                    Graphic,
                    Legend]) => 
        {
            var lat,lon;

            var lMaxIntensityValue = Math.max.apply(Math, this.state.locNewsMapData.map(function(o) { return o.totalTweets; }));
            console.log("max tensisyt value",lMaxIntensityValue);
            var graphics = this.state.locNewsMapData.map(function (news) 
            {
                    lat = news.latitude;
                    lon = news.longitude;
                    return new Graphic({
                        attributes: {
                            ObjectID: news.id,
                            totalTweets: news.totalTweets,
                            city: news.city
                        },
                        geometry: {
                            type: "point",
                            longitude: news.longitude,
                            latitude: news.latitude
                        }
                    });
            });
                
            setTimeout(5000);
            const simplerenderer = {
                type: "simple",
                field: "totalTweets",
                symbol: {
                    type: "simple-marker",
                    color: "#008B00",
                    outline: {
                        color: "white"
                    }
                },
                visualVariables: [
                {
                        type: "size",
                        field: "totalTweets",
                        stops: [
                        {
                            value: 100,
                            size: "10px"
                        },
                        {
                            value: 1000,
                            size: "20px"
                        },
                        {
                            value: 5000,
                            size: "30px"
                        },
                        {
                            value: 10000,
                            size: "40px"
                        }   
                        ]
                }
                ]
            };
            // const simplerenderer = {
            //     type: "simple", 
            //     symbol: {
            //         type: "simple-fill", 
            //         outline: {
            //             color: "CCFFCC",
            //             width: 0.5
            //         }
            //     },
            //     visualVariables: 
            //     [{
            //         type: "color", 
            //         field: "city",
            //         normalizationField: "totalTweets", 
            //         stops: 
            //         [
            //             {
            //                     value: 100, 
            //                     color: "#003300", 
            //                     label: "10% or lower" 
            //             },
            //             {
            //                     value: 10000, 
            //                     color: "#CCFFCC", 
            //                     label: "30% or higher" 
            //             }
            //         ]
            //     }]
            // };
            const heatmaprenderer = {
                    type: "heatmap",
                    field: "totalTweets",
                    colorStops: heatMapColor,
                    
                    minPixelIntensity: 0,
                    //maxPixelIntensity: 10000
                    maxPixelIntensity: lMaxIntensityValue
            };
             
            const popUpTemplate = {                     
                title: "Total News {totalTweets} originated from - {city}",
                content: [{
                        type: "fields",
                        fieldInfos: [
                        {
                            fieldName: "totalTweets",
                            label: "totalTweets",
                            visible: true
                        },
                        {
                            fieldName: "city",
                            label: "city",
                            visible: true
                        }
                        ]
                    }]
            };
       
            const featureLayer = new FeatureLayer({
                    title: "Tweets Heat Map",
                    source: graphics,
                    renderer: heatmaprenderer,
                    //renderer: simplerenderer,
                    popupTemplate: popUpTemplate,
                    objectIdField: "ObjectID",         
                    fields: [
                        {
                            name: "ObjectID",
                            alias: "ObjectID",
                            type: "oid"
                        },
                        {
                            name: "city",
                            alias: "city",
                            type: "string"
                        },
                        {
                            name: "totalTweets",
                            alias: "totalTweets",
                            type: "integer"
                        },
                    ]
            });  
            setTimeout(5000);

            const map = new Map({
                basemap: "dark-gray-vector"
                ,layers: [featureLayer]
            });

            const view = new MapView({
                container: 'NewsMapDiv',
                map: map,
                center: [lon, lat],
                zoom: 7
            });
            
            view.ui.add(
                new Legend({
                  view: view
                  //style: "card"
                }),
                "top-right"
            );
            // const basemapGallery = new BasemapGallery({
            //     view: view,
            //     container: basemapGalleryDiv
            // });
              
            // // Add the widget to the top-right corner of the view
            // view.ui.add(basemapGallery, {
            //     position: "bottom-right"
            // });
        });
        // }).catch(function(error){
        //     console.log("ERROR: in drawArcgisBubbleMap  ", error.details);
        // });
    }
    
    render(){ 
        return(
            <div id='NewsPageDiv' style={ styles.NewsPageDiv } >
                <div id='NewsMapDiv' width="400" height="300" style={ styles.NewsMapDiv } />
                <div id="basemapGalleryDiv" style={ styles.basemapGalleryDiv } ></div>
                <div id='NewsChartDiv' style={ styles.NewsChartDiv } >
                    <div className="news-container">
                        <div id="wordcloud" className="news-inner-upper-container-subpanel1">
                            <div className="news_wordcloud-text-div">
                                <label className="news_wordcloud-text-label">NEWS WORD CLOUD</label>
                            </div>
                        </div>
                        <div id="barchart" className="news-inner-upper-container-subpanel2" >
                                <div className="news_barchart-text-div">
                                    <label className="news_barchart-text-label">NEWS PER DAY</label>
                                </div>
                                {/* <div class="news_line-chart-speed-control-div">
                                   <div id="simpleslider" min="10" max="100" value="50"/>
                                </div> */}
                                <div className="news_total-count-text-div">
                                    <label className="news_total-count-text-label">Total News Count: </label>
                                    <label className="news_total-count-text-label1">{this.state.locTotalNewsCount} </label>
                                </div>            
                        </div>>
                    </div>
                </div> 
            </div>
        );
    }

}//class

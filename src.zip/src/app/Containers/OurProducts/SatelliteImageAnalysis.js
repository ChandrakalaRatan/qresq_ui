import React, { Component } from 'react';
const styles =  {
  SatellitePannelDiv: {
    marginLeft: 0, 
    marginTop: 0, 
    width: '120%',
    height: '100%',
    position: 'absolute',
    backgroundColor: 'black'
  }
}
export class SatelliteImageAnalysis extends React.Component {

  constructor(props) {
    super(props);
  }
    render(){
      console.log(JSON.stringify(this.props.SingleDisasterDataRecord));
      let qresqid = this.props.SingleDisasterDataRecord.qresqid;
      console.log(qresqid);
      let cycloneSrc ="http://localhost:8080"+"/app/Containers/OurProducts/qresqSatellite/src/weather.html?qresqid="+qresqid;
      let weatherSrc ="http://localhost:8080"+"/app/Containers/OurProducts/qresqSatellite/src/cyclone.html?qresqid="+qresqid;
      let satelliteSrc ="https://arcg.is/nODOb?qresqid="+qresqid;

        return (
          <div  id="SatellitePannelDiv" style={styles.SatellitePannelDiv} >  
                <div> 
                    <iframe id="CycloneTrack" 
                        style= {{ width:"55%", height:"400px", style:"border:none inherit 0px" }}
                        //src ="http://localhost:8080/app/Containers/OurProducts/qresqSatellite/src/weather.html"
                        src={cycloneSrc}
                    />
                    <iframe id="Weather" 
                        style= {{ width:"44%", height:"400px", style:"border:none inherit 0px" }}
                        // src="http://localhost:8080/app/Containers/OurProducts/qresqSatellite/src/cyclone.html"
                        src={weatherSrc}
                    />
              </div>
              <div style= {{ width:"100%", height:"500px", style:"border:none inherit 0px" }}>
                    <iframe id="Satellite" 
                        style= {{ width:"100%", height:"500px", style:"border:none inherit 0px" }}
                        //src="https://arcg.is/nODOb" 
                        src={satelliteSrc}
                    />
              </div>
          </div> 
        );
    }
}
export default SatelliteImageAnalysis;
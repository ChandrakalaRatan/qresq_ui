import React, { Component } from 'react';
import { loadModules } from 'esri-loader';
import drawBarChart from "./D3Charts/ScrollableBarChart";
import drawWordCloud from "./D3Charts/AnimatedWordCloud";
import drawLineGraph from "./D3Charts/LineGraph";
import "./TwitterPage.css";
import './D3Charts/Cloud';

import drawAnimatedLineGraph from "./D3Charts/AnimatedLineGraph";
import {barChartData} from "./D3Charts/BarChartData";

const options = {
    url: 'https://js.arcgis.com/4.12/'
    
};
//LIGHT GREEN
// const wordCloudColor=[ 
//                             '#CCFFCC','#C1FFC1','#9AFF9A','#66FF66','#33FF33',
//                             '#00FF00','#00EE00','#4BB74C','#00CD00','#009900',
//                             '#008B00','#008000','#006400','#004F00','#003300'
//                         ];

// DARK GREEN
// const wordCloudColor=[  
//                                 '#003300','#004F00','#006400','#008000','#008B00',
//                                 '#009900','#00CD00','#00EE00','#00FF00','#33FF33',
//                                 '#66FF66','#9AFF9A','#C1FFC1','#CCFFCC','#F0FFF0'
//                          ];

// // Dark BLUE
// const wordCloudColor=[ 
//                                 '#A4CEF8','#9CC8F3','#86BCF1','#60B1FF','#4DA5FF',
//                                 '#8DC5FE','#60AAF3','#509EEA','#2385E6','#1E90FF',
//                                 '#007FFF','#60AFFE','#1C86EE','#1874CD','#104E8B'
//                             ];       

// LIGHT BLUE
const wordCloudColor=[  
                                "#E5F9FF",'#99E5FF',"#93E4FF", "#88E1FF","#72DCFF",
                                "#4DD2FF","#41CFFF",'#2ACAFF','#2BCAFF','#00BEFE',
                                '#00BFFF','#00B2EE','#0099CC','#009ACD','#00688B','#104E8B'
                            ];
const barChartColor= [
                                "#191970","#0000EE","#E6E6FA"
                            ];
const heatMapColor = [
                                { color: "rgba(0,0,255, 0)", ratio: 0.05},
                                { color: "#191970',", ratio: 0.08 },
                                { color: "#000080", ratio: 0.12 },
                                { color: "#00008B", ratio: 0.1},
                                { color: "#00009C", ratio: 0.2},

                                { color: "#0000CD", ratio: 0.3 },
                                { color: "#0000EE", ratio: 0.4 },
                                { color: "#0000FF", ratio: 0.5},
                                { color: "#3333FF", ratio: 0.6 },

                                { color: "#6666FF", ratio: 0.7 },
                                { color: "#AAAAFF", ratio: 0.8 },
                                { color: "#CCCCFF", ratio: 0.9 },
                                { color: "#E6E6FA", ratio: 1},  
                            ];

const styles =  {
    TwitterPageDiv: {
        marginLeft: 0, 
        marginTop: 0, 
        width: '100%',
        height: '100%',
        position: 'absolute',
        backgroundColor: 'transparent'
    },
    TwitterMapDiv: {
        marginLeft: 0, 
        marginTop: 0, 
        width: '45%',
        height: '100%',
        position: 'absolute',
        backgroundColor: 'transparent'
    }, 
    TwitterChartDiv: {
        marginLeft: '45%',
        marginTop: 0, 
        width: '55%',
        height: '100%', 
        position: 'absolute',
        border: '1px solid black',
        outlineStyle: 'solid',
        outlineColor: 'invert',
        backgroundColor: 'transparent'
    }, 
}
  
export class TwitterPage extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            locTwitterBarChartData: [],
            locTwitterBarChartFlag: false,
            locTwitterWorldCloudData: [],
            locTwitterWorldCloudFlag: false,
            locTwitterMapData: [],
            locTwitterMapDataFlag: false,
            locTotalTweetsCount: 0
        }
    }
    componentDidMount() 
    {  
        this.twitterWordCloudFetch();
        this.twitterBarChartFetch();
        this.twitterMapFetch();
    }
    twitterMapFetch() 
    {  
        const endPoint =   //"http://167.86.104.221:8050/api/dasboard/groupByLocation?index=twitter_social_1&eventId="
                           // +this.props.SingleDisasterDataRecord.qresqid";
                            "http://167.86.104.221:8050/api/dasboard/groupByLocation?index=sc_twitter&eventId="
                           // +"1111";
                             +this.props.SingleDisasterDataRecord.qresqid;
                                
        fetch(endPoint,{
                      headers: {
                                  'Accept': 'application/json',
                                  'Content-Type': 'application/json'
                              },
                              method: "GET"
        })
        .then(response => response.json()) 
        .then(json => {
            var count=0;
            json.results.map(tweetsdata =>{
                this.state.locTwitterMapData.push({
                    "id" : count++,
                    "city": tweetsdata.city,
                    "totalTweets": tweetsdata.totalTweets,
                    "longitude": tweetsdata.geoLocation.lon,
                    "latitude": tweetsdata.geoLocation.lat
                })  
            });   
            this.setState({
                locTwitterMapDataFlag: true
            }) 
            console.log("twitterMapFetch",this.state.locTwitterMapData); 
        })
        .catch(error =>{
            console.log("ERROR" + error);     
        })                       
    }
    twitterBarChartFetch() 
    {  
        const endPoint =   //"http://167.86.104.221:8050/api/dasboard/tweetTrending?index=twitter_social&eventId="
                            // +this.props.SingleDisasterDataRecord.qresqid+"&groupBy=DAY";
                            "http://167.86.104.221:8050/api/dasboard/tweetTrending?index=sc_twitter&eventId="
                            //+"1111&groupBy=DAY";
                            +this.props.SingleDisasterDataRecord.qresqid+"&groupBy=DAY";
        fetch(endPoint,{
                headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json'
                        },
                        method: "GET"
        })
        .then(response => response.json()) 
        .then(json => {
            this.setState({
                locTwitterBarChartData: json.results,
                locTwitterBarChartFlag: true
            }) 
            console.log("twitterBarChartFetch",this.state.locTwitterBarChartData);               
        })
        .catch(error =>{
            console.log("ERROR" + error);     
        })           
    }

    twitterWordCloudFetch() 
    {  
        const endPoint = //"http://167.86.104.221:8050/api/dasboard/wordCloud?index=test_wordcloud&eventId="
                        //+this.props.SingleDisasterDataRecord.qresqid;
                        "http://167.86.104.221:8050/api/dasboard/wordCloud?index=sc_wordcloud&eventId="
                        //+"1111";
                        +this.props.SingleDisasterDataRecord.qresqid;
                        
        fetch(endPoint,{
            headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json'
                    },
                    method: "GET"
        })
        .then(response => response.json()) 
        .then(json => {
            this.setState({
                locTwitterWorldCloudData: json.results,
                locTwitterWorldCloudFlag: true
            })  
            console.log("twitterWordCloudFetch",this.state.locTwitterWorldCloudData);             
        })
        .catch(error =>{
            console.log("ERROR" + error);     
        })  
    }

    componentDidUpdate()
    {
        const wordCloudSelector = document.getElementById('wordcloud'); 
        const barChartSelector = document.getElementById('barchart'); 
        const sliderSelector = document.getElementById('slider-simple');
        var wordCloudJsonData =[];
        var maxTweets = Math.max.apply(Math, this.state.locTwitterWorldCloudData.map(o=> { return o.totalTweets; }));
        var tweetCount= Math.floor(maxTweets/5);
        this.state.locTwitterWorldCloudData.map(jsondata =>{
                if(jsondata.totalTweets > 0 && jsondata.totalTweets <= tweetCount)
                {
                    wordCloudJsonData.push({
                        text: jsondata.word,
                        totalTweets: jsondata.totalTweets,
                        size: 14
                    }) 
                }
                if(jsondata.totalTweets > tweetCount && jsondata.totalTweets <= tweetCount*2)
                {
                    wordCloudJsonData.push({
                        text: jsondata.word,
                        totalTweets: jsondata.totalTweets,
                        size: 18
                    }) 
                }
                else if(jsondata.totalTweets > tweetCount*2 && jsondata.totalTweets <= tweetCount*3){
                    wordCloudJsonData.push({
                        text: jsondata.word,
                        totalTweets: jsondata.totalTweets,
                        size: 22
                    })  
                }
                else if(jsondata.totalTweets > tweetCount*3 && jsondata.totalTweets <= tweetCount*4){
                    wordCloudJsonData.push({
                        text: jsondata.word,
                        totalTweets: jsondata.totalTweets,
                        size: 26
                    })  
                }
                else if(jsondata.totalTweets > tweetCount*4 && jsondata.totalTweets <= tweetCount*5){
                    wordCloudJsonData.push({
                        text: jsondata.word,
                        totalTweets: jsondata.totalTweets,
                        size: 30
                    }) 
                }
             
        });
 
        if(this.state.locTwitterWorldCloudFlag === true){ 
            drawWordCloud(wordCloudJsonData, wordCloudSelector,wordCloudColor);
            this.setState({
                locTwitterWorldCloudFlag: false
            });
        }
        
        if(this.state.locTwitterBarChartFlag === true){
            this.state.locTwitterBarChartData.map(d=>{ 
                this.state.locTotalTweetsCount = this.state.locTotalTweetsCount + d.totalTweets
            })
             //drawBarChart(barChartData, barChartSelector,barChartColor);
            //drawLineGraph(this.state.locTwitterBarChartData, barChartSelector,barChartColor);
            drawAnimatedLineGraph(this.state.locTwitterBarChartData, sliderSelector,barChartSelector,barChartColor);
            this.setState({
                locTwitterBarChartFlag: false
            });
        }
        if(this.state.locTwitterMapDataFlag === true){
            this.drawArcgisHeatMap();
            this.setState({
                locTwitterMapDataFlag: false
            });
        }
    }

    drawArcgisHeatMap()
    {
        loadModules([   
            "esri/Map",
            "esri/views/MapView",
            "esri/layers/FeatureLayer",
            "esri/Graphic",
            "esri/widgets/Legend"], 
            options)
        .then(([    
                Map, 
                MapView, 
                FeatureLayer,
                Graphic,
                Legend]) => 
        {
            var lat,lon;
            var lMaxIntensityValue = Math.max.apply(Math, this.state.locTwitterMapData.map(function(o) { return o.totalTweets; }));
            var graphics = this.state.locTwitterMapData.map(function (tweets) {
                lat = tweets.latitude;
                lon = tweets.longitude;
                return new Graphic({
                  attributes: {
                    ObjectID: tweets.id,
                    totalTweets: tweets.totalTweets,
                    city: tweets.city
                  },
                  geometry: {
                    type: "point",
                    longitude: tweets.longitude,
                    latitude: tweets.latitude
                  }
                });
            });
            //console.log(JSON.stringify(graphics));
            setTimeout(5000);
           
            const heatmaprenderer = {
                type: "heatmap",
                field: "totalTweets",
                colorStops: heatMapColor,
                minPixelIntensity: 0,
                maxPixelIntensity: lMaxIntensityValue
            };
       
            var popUpTemplate = {                    
                title: "Total Tweets {totalTweets} originated from - {city}",
                content: [{
                    type: "fields",
                    fieldInfos: [
                    {
                        fieldName: "totalTweets",
                        label: "totalTweets",
                        visible: true
                    },
                    {
                        fieldName: "city",
                        label: "city",
                        visible: true
                    }
                    ]
                }]
            }
            const featureLayer = new FeatureLayer({
                    source: graphics,
                    renderer: heatmaprenderer,
                    popupTemplate: popUpTemplate,
                    objectIdField: "ObjectID",          
                    fields: [
                        {
                            name: "ObjectID",
                            alias: "ObjectID",
                            type: "oid"
                        },
                        {
                            name: "city",
                            alias: "city",
                            type: "string"
                        },
                        {
                            name: "totalTweets",
                            alias: "totalTweets",
                            type: "integer"
                        },
                    ]
            });  
            setTimeout(5000);
            const map = new Map({
                basemap: "dark-gray-vector",
                layers: [featureLayer]
            });

            const view = new MapView({
                container: "TwitterMapDiv",
                center: [lon, lat],
                zoom: 7,
                map: map
            });  
            view.ui.add(
                new Legend({
                  view: view
                }),
                "top-right"
            );           
        }); //then      
    }

    render(){ 
        return(
            <div id='TwitterPageDiv' style={ styles.TwitterPageDiv } >
                <div id='TwitterMapDiv' style={ styles.TwitterMapDiv }/>
                <div id='TwitterChartDiv' style={ styles.TwitterChartDiv } >
                    <div className="tweet-container">
                        <div id="wordcloud" className="tweet-inner-upper-container-subpanel1">
                            <div className="tweet_wordcloud-text-div">
                                <label className="tweet_wordcloud-text-label">TWEETS WORD CLOUD</label>
                            </div>
                        </div>
                        <div id="barchart" className="tweet-inner-upper-container-subpanel2" >
                            <div className="tweet_barchart-text-div">
                                <label className="tweet_barchart-text-label">TWEETS PER DAY</label>
                            </div>
                            {/* <div class="tweet_line-chart-speed-control-div">
                                   <div id="slider-simple"/>
                            </div> */}
                            <div className="tweet_total-count-text-div">
                                <label className="tweet_total-count-text-label">Total Tweets : </label>
                                <label className="tweet_total-count-text-label1">{this.state.locTotalTweetsCount} </label>
                            </div>
                        </div>
                     </div>
                </div>
            </div>
        );
    }

}//class

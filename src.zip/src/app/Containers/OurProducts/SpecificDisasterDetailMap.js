import React, { Component, Fragment } from 'react';
import ReactDOM from "react-dom";

import {ButtonToolbar, Button } from 'react-bootstrap';
import {DetailDisasterSummary } from './DetailDisasterSummary';

import {GoogleCrisisMap} from './GoogleCrisisMap';
import {TwitterPage} from "./TwitterPage";
import {NewsPage} from './NewsPage';

import {SocialMediaSector} from './SocialMediaSector';
import {SatelliteImageAnalysis} from './SatelliteImageAnalysis';

import "./SpecificDisasterDetailMap.css";



const options = {
    url: 'https://js.arcgis.com/4.8/'
};
const styles =  {
    SpecificDisasterDetailMapContainer: {
        height: '100%',
        width: '100%',
        backgroundColor: 'black'
    },
    UpperPannelDiv: {
        marginLeft: 0, 
        marginTop: 0, 
        width: '100%',
        height: '81%',
        position: 'relative',
        backgroundColor: 'black'
    },
    LowerPanelDive: {
        top: '0%',
        width: '100%',
        height: '20%', 
        position: 'relative',
        backgroundColor: 'black'
    }
}

export class SpecificDisasterDetailMap extends React.Component{

    constructor(props) {
        super(props);
        this.socialcontainerEl1 = null;
        this.satellitecontainerEl = null;
        this.socialWindow = null;
        this.satelliteWindow = null;
        this.state = {
            sDetailDisasterReportData: [],
            selectedOption: 'news',
            sGoogleCrisisMapFlag: false,
            sSocialMediaFlag: false,
            sSatelliteImageFlag: false,
            sTwitterFlag: false,
            sNewsFlag: false
        }
    }
    detailSummaryFetch() 
    {  
        const endPoint = "http://167.86.104.221:8050/api/qresq/search";
        fetch(endPoint,{
            headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    method: "POST",
                    body: JSON.stringify({
                        exactMatch : true,
                        filters: [
                                    {
                                        fieldName: "qresqid",
                                        value: this.props.SingleDisasterDataRecord.qresqid
                                    }
                        ],
                        from: 0,
                        indexName: "test_summary",
                        size: 20 
                    })
                })
                .then(response => response.json()) 
                .then(json => {
                    var array=[];
                    var index = 0;
            
                    json.results.map(result =>{
                        Object.keys(result.summary).map(key => {
                            array.push({
                            index: index++,
                            date: key,
                            content: result.summary[key]
                            }) 
                        })                
                    })
                    this.setState({
                        sDetailDisasterReportData: array
                    }) 
                    console.log(json); 
                })
                .catch(error =>{
                console.log("ERROR" + error);     
                })                
    }
    componentDidMount() 
    {  
        document.getElementById("news").checked=true;
        this.setState({ sNewsFlag: true });
        this.detailSummaryFetch();
    }
 
    renderMap() {    
        if(this.state.status === 'loading') {
            return <div>loading</div>;
        }
    }//renderMap
    renderRadioButton()
    {
        return(
            <div id="radioBtnDiv" className="panel-radio-button">
                <label className="radio-label">
                <input  type="radio" 
                        id="news" 
                        className="radio-button" 
                        name="radio" 
                        value="news" 
                        onChange={this.radioButtonClickHandle.bind(this)}
                />NEWS</label><br/>
                <label className="radio-label">
                <input  type="radio" 
                        id="twitter" 
                        className="radio-button" 
                        name="radio" 
                        value="twitter" 
                        onChange={this.radioButtonClickHandle.bind(this)}
                />TWITTER</label><br/>
                <label className="radio-label">
                <input  type="radio" 
                            id="googlecrisismap"
                            className="radio-button" 
                            name="radio" 
                            value="googlecrisismap" 
                            onChange={this.radioButtonClickHandle.bind(this)}
                />GOOGLE CRISIS MAP</label><br/>   
            </div>   
        )
    }
    radioButtonClickHandle(e){
        this.setState({
                        sGoogleCrisisMapFlag: false,
                        sTwitterFlag: false,
                        sNewsFlag: false
                  
        });
        this.setState({
          selectedOption: e.target.value
        });
        if(e.target.value === 'googlecrisismap')
        {
          this.setState({sGoogleCrisisMapFlag: true }); 
          document.getElementById("googlecrisismap").checked=true;
        }
        if(e.target.value === 'twitter')
        {
          this.setState({sTwitterFlag: true }); 
          document.getElementById("twitter").checked=true;
        }
        if(e.target.value === 'news')
        {
          this.setState({sNewsFlag: true }); 
          document.getElementById("news").checked=true;
          //D3Chloropeth();   
        }
    }
  
    renderButton()
    {
        return(
            <div id="btnDiv" className="panel-summery-button">
                <ButtonToolbar className="summary-button-group"
                                    onClick={this.buttonClickHandle.bind(this)}>
                    <Button className="social_media_button" type="submit" id="socialmedia">SOCIAL MEDIA ANALYSIS</Button> 
                    <Button className="satellite_image_button" type="submit" id="satelliteimage">SATELLITE DATA ANALYSIS</Button>   
                </ButtonToolbar>
            </div>
        )
    }

    buttonClickHandle(e){
        this.setState({ 
                        sSocialMediaFlag: false,
                        sSatelliteImageFlag:false
                      });

        if(e.target.id === "socialmedia")
        {
            //this.setState({sSocialMediaFlag: true });  
            this.openSocialMediaWindow();
        }
        if(e.target.id === "satelliteimage")
        {
            this.setState({sSatelliteImageFlag: true });  
            this.openSatelliteImageWindow();
        }       
    }
    openSocialMediaWindow() 
    { 
        console.log("i am in openSocialMediaWindow"); 
        let socialwindowTitle = "Social Media Analysis"
        this.socialWindow = window.open('http://localhost:8080/socialmedia', socialwindowTitle, 'width=1200,height=800,left=10,top=10');
        this.socialcontainerEl = document.createElement('div');
        this.socialWindow.addEventListener('load', ()=>{
            this.socialWindow.document.title = socialwindowTitle;
            if (this.socialWindow) {
                let root = this.socialWindow.document.body.appendChild(this.socialcontainerEl);
                ReactDOM.render(<SocialMediaSector  
                    SingleDisasterDataRecord={this.props.SingleDisasterDataRecord} 
                    />, root);
            }
        }, false);
    }
    openSatelliteImageWindow() 
    { 
        console.log("i am in openSatelliteImageWindow"); 
       let satellitewindowTitle = "Satellite Image Anaysis"
        this.satelliteWindow = window.open('http://localhost:8080/satelliteimage', satellitewindowTitle, 'width=1200,height=1000');
        this.satellitecontainerEl = document.createElement('div');
        this.satelliteWindow.addEventListener('load', ()=>{
            this.satelliteWindow.document.title = satellitewindowTitle;
            if (this.satelliteWindow) {
                let root = this.satelliteWindow.document.body.appendChild(this.satellitecontainerEl);
                ReactDOM.render(<SatelliteImageAnalysis  
                   SingleDisasterDataRecord={this.props.SingleDisasterDataRecord} 
                />, root);
            }
        }, false);
    }
  
    render() {
        return( 
            <div  id="SpecificDisasterDetailMapContainer" style={styles.SpecificDisasterDetailMapContainer} > 
                <div  id="UpperPannelDiv" style={styles.UpperPannelDiv} >
                    { this.state.sGoogleCrisisMapFlag && 
                        <GoogleCrisisMap />              
                    }
                    {this.state.sTwitterFlag &&
                        <TwitterPage  SingleDisasterDataRecord={this.props.SingleDisasterDataRecord}/>
                    }
                    {this.state.sNewsFlag &&
                        <NewsPage  SingleDisasterDataRecord={this.props.SingleDisasterDataRecord}/>
                    }
                    {this.renderRadioButton() }
                    {this.renderButton()} 
                </div>
                <div id='LowerPanelDive' style={ styles.LowerPanelDive }  >
                    <DetailDisasterSummary slides={this.state.sDetailDisasterReportData} /> 
                </div>
                { this.state.sSocialMediaFlag &&
                    <SocialMediaSector 
                        SingleDisasterDataRecord={this.props.SingleDisasterDataRecord}
                        latitude={this.props.latitude} 
                        longitude={this.props.longitude}
                    />               
                } 
            </div>  
        ) //return
    }//render
}//class

export default SpecificDisasterDetailMap;



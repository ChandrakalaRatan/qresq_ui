import React, { Component } from 'react';
import ReactDOM from "react-dom";
import "./SocialMediaSector.css";
// import {TwitterPage} from "./TwitterPage";
import drawPieChart from "./D3Charts/PieChart";

const styles =  {
    SocialPannelDiv: {
        marginLeft: 0, 
        marginTop: 0, 
        width: '100%',
        height: '100%',
        position: 'absolute',
        backgroundColor: 'black'
    }
}

export class SocialMediaSector extends React.Component{
        constructor(props) {
            super(props);
            this.inputText = React.createRef();
            this.state = {
                
                // blogFlag: false,
                // forumFlag: false,
                // forumMentions: 60000,
                //blogPercentage:0,
                //forumPercentage:0,
                // blogMentions: 200000,

                twitterFlag: false,
                positiveTweets: 0,
                negativeTweets:0,
                neutralTweets: 0,
                positiveTweetsPercentage: 0,
                negativeTweetsPercentage:0,
                neutralTweetsPercentage: 0,
                totalTweets: 0,
                locTwitterSentimentData: {},
                locTwitterSentimentFlag: false,
                totalTwitterPercentage:0,

                newsFlag: false,
                positiveNews: 0,
                negativeNews:0,
                neutralNews: 0,
                positiveNewsPercentage: 0,
                negativeNewsPercentage:0,
                neutralNewsPercentage: 0,

                totalNews:0,
                locNewsSentimentData: {},
                locNewsSentimentFlag: false,
                totalNewsPercentage:0,

                totalMentions: 0
            }
        }

    twitterSentimentFetch()
    {
        const endPoint1 =  "http://167.86.104.221:8050/api/tweet/fetchSentiment?index=sc_twitter&eventId="
                            +this.props.SingleDisasterDataRecord.qresqid;
        fetch(endPoint1,{
            headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    method: "GET"
                })
                .then(response => response.json()) 
                .then(json => {
                    console.log("json" + JSON.stringify(json.results));   
                    this.setState({
                        locTwitterSentimentFlag: true,
                        totalTweets: Number(json.results.totalTweets),
                        positiveTweets: Number(json.results.postiveTweets),
                        negativeTweets: Number(json.results.negativeTweets),
                        neutralTweets: ( Number(json.results.totalTweets) -
                            (   Number(json.results.negativeTweets) + 
                                Number(json.results.postiveTweets)   ) )
                    });
                    this.setState({
                        positiveTweetsPercentage: this.state.positiveTweets !== 0 ?
                                     Math.round(  (this.state.positiveTweets/this.state.totalTweets)*100 ):0,
                        negativeTweetsPercentage: this.state.negativeTweets !== 0 ?
                                    Math.round(  (this.state.negativeTweets/this.state.totalTweets)*100 ):0,
                        neutralTweetsPercentage: this.state.neutralTweets !== 0 ?
                                    Math.round(  (this.state.neutralTweets/this.state.totalTweets)*100 ):0,
                    }) 
                })
                .catch(error =>{
                console.log("ERROR" + error);     
                })   
    }
    newsSentimentFetch()
    {
        const endPoint2 =  "http://167.86.104.221:8050/api/tweet/fetchSentiment?index=test_news&eventId="
                            +this.props.SingleDisasterDataRecord.qresqid;
        fetch(endPoint2,{
            headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    method: "GET"
                })
                .then(response => response.json()) 
                .then(json => {
                
                    this.setState({
                        locNewsSentimentFlag: true,
                        totalNews: Number(json.results.totalTweets),
                        positiveNews: Number(json.results.postiveTweets),
                        negativeNews: Number(json.results.negativeTweets),
                        neutralNews:  (   Number(json.results.totalTweets) - 
                                        (Number(json.results.negativeTweets) + 
                                        Number(json.results.postiveTweets)    ) )
                    });
                    this.setState({
                        positiveNewsPercentage: this.state.positiveNews !== 0 ?
                            Math.round(  (this.state.positiveNews/this.state.totalNews)*100 ):0,
                        negativeNewsPercentage: this.state.negativeNews !== 0 ?
                            Math.round(  (this.state.negativeNews/this.state.totalNews)*100 ):0,
                        neutralNewsPercentage: this.state.neutralNews !== 0 ?
                            Math.round(  (this.state.neutralNews/this.state.totalNews)*100 ):0,
                    })  
        })
        .catch(error =>{
            console.log("ERROR" + error);     
        })   
    }
    componentDidMount() 
    {  
        this.twitterSentimentFetch();
        this.newsSentimentFetch();     
    }
    componentDidUpdate(){
    //     var SocialMediaDiv = document.getElementById('SocialMediaDiv'); 
    //     var firstpanel = document.getElementById('firstpanel'); 
    //     var secondpanel = document.getElementById('secondpanel'); 
    //     var pieChartSelector = document.getElementById('pieChart'); 
    //     console.log("SocialMediaDiv" + SocialMediaDiv); 
    //     console.log("firstpanel" + firstpanel); 
    //     console.log("secondpanel" + secondpanel); 
    //    console.log("pieChartSelector" + pieChartSelector); 
    //    const node2 = ReactDOM.findDOMNode(this);
    //    console.log("node2",node2); 
        const node1 = this.inputText.current;
        console.log("node1" + node1); 
        const pieChartJsonData = {Twitter:this.state.totalTwitterPercentage,
                                  News: this.state.totalNewsPercentage
                                };
        if(this.state.locTwitterSentimentFlag === true){
            drawPieChart(pieChartJsonData, node1)
            this.setState({
                locTwitterSentimentFlag: false
            });
        }  
    }
    renderUpperLeftPanel(){
        return(
                <div className="social-inner-upper-left-panel">
                    <div className="total-mention">
                        <div className="total-mention-text-div">
                            <label className="total-mention-text">
                                TOTAL MENTIONS
                            </label>
                        </div>
                        <div className="total-mention-value-div">
                            <label className="total-mention-value">
                            {this.state.totalMentions}
                            </label>
                        </div>
                    </div>

                    <div className="overall-mention-label-div">
                        <label className="overall-mention-label">OVERALL MENTIONS</label>
                    </div>

                    <div className="blog-twitter-news-forum-button-div">
        
                        <div className="twitter-div">
                            <div className="twitter-label-div">
                                <label className="button-header-text">TWITTER</label>
                            </div>
                            <div className="twitter-button-div" >
                                <div className="twitter-shade-div" style= {{ width: this.state.totalTwitterPercentage+'%'}}/>
                                <div className="percentage1-div" >
                                    <label className="button-text">{this.state.totalTwitterPercentage}% </label>
                                </div>
                                <div className="label-div">
                                    <label className="button-text"> {this.state.totalTweets}</label>
                                </div>
                            </div>
                        </div>
                        <div className="news-div" >
                            <div className="news-label-div">
                                <label className="button-header-text">NEWS</label>
                            </div>
                            <div className="news-button-div">
                                <div className="news-shade-div" style= {{ width: this.state.totalNewsPercentage+'%'}}/>
                                <div className="percentage1-div" >
                                    <label className="button-text">{this.state.totalNewsPercentage}%</label>
                                </div>
                                <div className="label-div">
                                    <label className="button-text">{this.state.totalNews}</label>
                                </div>
                                </div>
                        </div>
                    </div>
                </div>
        );
    }
    renderTwitterSentiment(){
        return(
            <div className="social-lower-inner-panel">
                <div className="overall-sentiment-label-div">
                        <label className="overall-sentiment-label">OVERALL TWITTER SENTIMENT</label>
                </div>
                <div className="sentiment-bar">
                        <div className="sentiment-bar-negative" 
                            style= {{   width: this.state.negativeTweetsPercentage +'%' 
                                        //,marginLeft: '0%'
                                    }} >
                            <div    className="sentiment-bar-negative-shade-div"/>
                        </div>
                        <div className="sentiment-bar-neutral"   
                            style= {{   width: this.state.neutralTweetsPercentage +'%'
                                        //,marginLeft: this.state.negativeTweets+'%' 
                                    }} >
                            <div    className="sentiment-bar-neutral-shade-div" />
                        </div>                            
                        <div className="sentiment-bar-positive"  
                            style= {{   width: this.state.positiveTweetsPercentage+'%' 
                                        //,marginLeft: (this.state.negativeTweets + this.state.neutralTweets)+'%' 
                                    }} >
                            <div    className="sentiment-bar-positive-shade-div"/>
                        </div>
                </div>

                <div className="sentiment-bar-percentage-text-div">
                        <div className="sentiment-bar-negative-percentage-text-div"
                                style= {{   width: this.state.negativeTweetsPercentage +'%' 
                                //,marginLeft: '0%'
                                }} > 
                            <label  className="negative-percentage-text">
                                    {this.state.negativeTweetsPercentage} %</label></div>
                        <div className="sentiment-bar-neutral-percentage-text-div" 
                                    style= {{   width: this.state.neutralTweetsPercentage +'%'
                                    //,marginLeft: this.state.negativeTweets+'%' 
                                    }} > 
                            <label  className="neutral-percentage-text"> 
                                    {this.state.neutralTweetsPercentage} %</label></div>
                        <div className="sentiment-bar-positive-percentage-text-div" 
                                    style= {{   width: this.state.positiveTweetsPercentage+'%' 
                                    //,marginLeft: (this.state.negativeTweets + this.state.neutralTweets)+'%' 
                                    }}  >
                            <label className="positive-percentage-text">
                                {this.state.positiveTweetsPercentage} %</label></div>
                </div>

                <div className="sentiment-description-text-div">
                        <label className="sentiment-description-text">
                        sentiments of conversation -
                        {this.state.positiveTweetsPercentage}%  positvie, 
                        {this.state.negativeTweetsPercentage}%  negative  and  
                        {this.state.neutralTweetsPercentage}%  neutral
                        </label>
                </div> 
            </div>
        );
    }
    renderNewsSentiment(){
        return(
            <div className="social-lower-inner-panel">
                <div className="overall-sentiment-label-div">
                        <label className="overall-sentiment-label">OVERALL NEWS SENTIMENT</label>
                </div>
                <div className="sentiment-bar">
                        <div className="sentiment-bar-negative" 
                            style= {{   width: this.state.negativeNewsPercentage +'%' 
                                        //,marginLeft: '0%'
                                    }} >
                            <div    className="sentiment-bar-negative-shade-div"/>
                        </div>
                        <div className="sentiment-bar-neutral"   
                            style= {{   width: this.state.neutralNewsPercentage +'%'
                                        //,marginLeft: this.state.negativeTweets+'%' 
                                    }} >
                            <div    className="sentiment-bar-neutral-shade-div" />
                        </div>                            
                        <div className="sentiment-bar-positive"  
                            style= {{   width: this.state.positiveNewsPercentage+'%' 
                                        //,marginLeft: (this.state.negativeTweets + this.state.neutralTweets)+'%' 
                                    }} >
                            <div    className="sentiment-bar-positive-shade-div"/>
                        </div>
                </div>

                <div className="sentiment-bar-percentage-text-div">
                        <div className="sentiment-bar-negative-percentage-text-div" 
                                style= {{   width: this.state.negativeNewsPercentage +'%' 
                                        //,marginLeft: '0%'
                                    }} > 
                            <label className="negative-percentage-text">{this.state.negativeNewsPercentage} %</label></div>
                        <div className="sentiment-bar-neutral-percentage-text-div"  
                                style= {{   width: this.state.neutralNewsPercentage +'%'
                                        //,marginLeft: this.state.negativeTweets+'%' 
                                    }} >
                            <label className="neutral-percentage-text"> {this.state.neutralNewsPercentage} %</label></div>
                        <div className="sentiment-bar-positive-percentage-text-div" 
                                    style= {{   width: this.state.positiveNewsPercentage+'%' 
                                        //,marginLeft: (this.state.negativeTweets + this.state.neutralTweets)+'%' 
                                    }} >
                            <label className="positive-percentage-text"> {this.state.positiveNewsPercentage} %</label></div>
                </div>

                <div className="sentiment-description-text-div">
                        <label className="sentiment-description-text">
                        sentiments of conversation -
                        {this.state.positiveNewsPercentage}%   positvie,  
                        {this.state.negativeNewsPercentage}%   negative  and  
                        {this.state.neutralNewsPercentage}%   neutral
                        </label>
                </div> 
            </div>
        );
    }

    renderPanel(){
        this.state.totalMentions = Math.round(this.state.totalNews + this.state.totalTweets);
        this.state.totalNewsPercentage = this.state.totalNews !== 0 ?
            Math.round( (this.state.totalNews/this.state.totalMentions) *100):0;
        this.state.totalTwitterPercentage = this.state.totalTweets !== 0 ?
            Math.round( (this.state.totalTweets/this.state.totalMentions) *100):0;
        return(
            <div id="firstpanel" className="social-panel" >
                <div className="social-panel-header-label-div" >
                    <label className="social-panel-header-label">SOCIAL MEDIA ANALYSIS</label>
                </div>
                <div id="secondpanel" className="social-upper-panel">
                    {this.renderUpperLeftPanel()}
                    <div id="pieChart" ref={this.inputText} className="social-inner-upper-right-panel"/>
                </div>
                <div className="social-lower-panel">
                    {this.renderTwitterSentiment()}
                    {this.renderNewsSentiment()}
                </div>
            </div>
        );
    }
    // socialMediaButtonClick(e)
    // {
    //     if(e.target.id === "twitter"){
    //         this.setState({twitterFlag: true}); 
    //     }
    //    if(e.target.id === "news"){
    //         this.setState({newsFlag: true});  
    //     }
    // }
    render(){
        return(
            <div id="SocialMediaDiv" style={styles.SocialPannelDiv} >
                {this.renderPanel()}
                {/* {this.state.twitterFlag &&
                    <TwitterSocialPage totalTweets={this.state.totalTweets} 
                        SingleDisasterDataRecord={this.props.SingleDisasterDataRecord}/>}
                {this.state.newsFlag &&
                    <NewsSocialPage/>} */}
            </div>
        );
    }

}//class

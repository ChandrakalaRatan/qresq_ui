import React from "react";
import {ButtonToolbar, Button } from 'react-bootstrap';

import { AllDisasterMap } from "./AllDisasterMap";
import './ResqHome.css';



//var gDateRange = 'MONTH';
var gDisasterType = 'ALL';

export class ResqHome extends React.Component{
    constructor(props) {
        super(props);  
        this.state = {
            week_button: true,
            month_button: false,
            all_button: false,
            earthquake_button: true,
            flood_button: true,
            storm_button: true,
            humanitarian_button: true,

            requirementKey: Math.random(),
            sDisasterTypeFilter:{},
           // sDateRangeFilter: {},
            sDateAndDisasterFilter: [
                // {
                //     fieldName: 'dateOccur',
                //     type: 'RANGE',
                //     value: 1,
                //     distance: 'MONTH'
                // }
            ]
        } 
    } 
    handleSubmitBannerClick(e)
    {
        this.setState({
            requirementKey: Math.random(),
        });
       
        this.state.sDateAndDisasterFilter.pop();
        //this.state.sDateAndDisasterFilter.pop();
        // this.state.sDateRangeFilter.fieldName= 'dateOccur';
        // this.state.sDateRangeFilter.type = 'RANGE';
        // this.state.sDateRangeFilter.value = 1;
        
        this.state.sDisasterTypeFilter.fieldName= 'disasterType';
        this.state.sDisasterTypeFilter.type = 'string';
       
        // if( e.target.id === "MONTH"  )
        // {
        //     gDateRange = e.target.id;
        //     this.setState({ 
        //         week_button: true,
        //         month_button:false
                
        //     }); 
        // }
        // else if( e.target.id === "WEEK")
        // {
        //     gDateRange = e.target.id;
        //     this.setState({ 
        //         month_button: true, 
        //         week_button:false
        //     });  
        // }
        // this.state.sDateRangeFilter.distance = gDateRange;
        // this.state.sDateAndDisasterFilter.push(  this.state.sDateRangeFilter );

        if(e.target.id === "EQ"){
            gDisasterType = e.target.id;
            this.setState({ 
                all_button: true,
                flood_button: true,
                storm_button: true,
                humanitarian_button: true, 
                earthquake_button:false,
            });
        }
        else if(e.target.id === "HU"){
            gDisasterType = e.target.id;
            this.setState({   
                all_button: true,
                flood_button: true,
                storm_button: true,
                earthquake_button:true, 
                humanitarian_button:false
            });
        }
        else if(e.target.id === "FL"){
            gDisasterType = e.target.id;
            this.setState({ 
                all_button: true,
                storm_button: true,
                earthquake_button:true, 
                humanitarian_button:true,  
                flood_button:false   
            });
        }
        else if(e.target.id === "TC"){
            gDisasterType = e.target.id;
            this.setState({ 
                all_button: true,   
                earthquake_button:true, 
                humanitarian_button:true,  
                flood_button:true,   
                storm_button:false  
            });  
        }
        else if(e.target.id  === "ALL")
        {
            gDisasterType = e.target.id;
            this.setState({
                earthquake_button:true, 
                humanitarian_button:true,  
                flood_button:true,   
                storm_button:true, 
                all_button: false,
            }); 
        }
        this.state.sDisasterTypeFilter.value = gDisasterType;
        if(gDisasterType  !== "ALL"){
            
            this.state.sDateAndDisasterFilter.push( this.state.sDisasterTypeFilter  ); 
        } 
    }

    renderBanner(){
        return(
            <div className="resq-banner">       
                <div className="resq-logo"> 
                    <div className="resq__logo_img">  
                        <a href='/'>
                            <img src={"http://localhost:8080/Images/qresqlogo.png"} 
                                align="bottom" width="40" height="60"/>
                        </a> 
                    </div> 
                </div>
                <div className="resq-daterange"> 
                    {/* <div className="date-range-header">DATE RANGE</div>
                    <ButtonToolbar className="date-range-button-group"
                                            onClick={this.handleSubmitBannerClick.bind(this)}>
                        <Button className={this.state.month_button ? "button_white": "button_orange"} type="submit" id="MONTH">ONE MONTH</Button>
                        <Button className={this.state.week_button ? "button_white": "button_orange"} type="submit" id="WEEK">ONE WEEK</Button>
                    </ButtonToolbar> */}
                </div>
                <div className="resq-disastertype">
                    <div className="disaster-type-header">DISASTER TYPE</div>            
                        <ButtonToolbar className="disaster-type-button-group"
                                            onClick={this.handleSubmitBannerClick.bind(this)}>
                            <Button className={this.state.all_button ? "button_white": "button_orange"}  type="submit" id="ALL">ALL</Button>
                            <Button className={this.state.earthquake_button ? "button_white": "button_orange"}  type="submit"  id="EQ">EARTHQUAKE</Button>
                            <Button className={this.state.flood_button ? "button_white": "button_orange"} type="submit" id="FL" >FLOOD</Button>
                            <Button className={this.state.storm_button ? "button_white": "button_orange"}  type="submit" id="TC">STORM</Button>
                            <Button className={this.state.humanitarian_button ? "button_white": "button_orange"} type="submit" id="HU">HUMANITARIAN</Button>        
                        </ButtonToolbar>
                </div>   
            </div>  
        )
    }

    render() 
    {
        return(
            <div id="ResqHomeParentDiv" className="resq-new-window">  
                {this.renderBanner()}
                <div id="ResqHomeDiv" className="resq-wrapper" > 
                    <AllDisasterMap 
                        key={this.state.requirementKey}
                        sDateAndDisasterFilter ={this.state.sDateAndDisasterFilter} />
                </div> 
            </div>      
        );  
    }//render 
}//class
    
import React from "react";
import ReactDOM from 'react-dom';

import './DataPolicy.css';


export class DataPolicy extends React.Component{
  
    render() {
        return (
            <div className="home">
      
            <div className="home-left-banner">
            left banner</div>  
            <div className="home-right-banner">
            right banner</div>
        </div>
     );
        
    }
}

